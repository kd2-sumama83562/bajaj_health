package com.bajaj;

import org.json.JSONObject;
import org.json.JSONTokener;
import org.apache.commons.codec.digest.DigestUtils;

import java.io.FileReader;
import java.io.IOException;
import java.security.SecureRandom;
import java.util.Random;

public class HashGenerator {

    public static void main(String[] args) {
        if (args.length != 2) {
            System.out.println("Usage: java -jar DestinationHashGenerator.jar <240340820055> </destination-hash-generator/sample.json>");
            return;
        }

        String prnNumber = args[0].trim().toLowerCase();
        String jsonFilePath = args[1].trim();

        try {
            String destinationValue = extractDestinationValue(jsonFilePath);
            if (destinationValue == null) {
                System.out.println("Key 'destination' not found in the JSON file.");
                return;
            }

            String randomString = generateRandomString(8);
            String concatenatedString = prnNumber + destinationValue + randomString;
            String md5Hash = DigestUtils.md5Hex(concatenatedString);

            System.out.println(md5Hash + ";" + randomString);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static String extractDestinationValue(String filePath) throws IOException {
        try (FileReader reader = new FileReader(filePath)) {
            JSONTokener tokener = new JSONTokener(reader);
            JSONObject jsonObject = new JSONObject(tokener);
            return findFirstDestinationValue(jsonObject);
        }
    }

    private static String findFirstDestinationValue(JSONObject jsonObject) {
        if (jsonObject.has("destination")) {
            return jsonObject.getString("destination");
        }

        for (String key : jsonObject.keySet()) {
            Object value = jsonObject.get(key);
            if (value instanceof JSONObject) {
                String result = findFirstDestinationValue((JSONObject) value);
                if (result != null) {
                    return result;
                }
            } else if (value instanceof org.json.JSONArray) {
                org.json.JSONArray array = (org.json.JSONArray) value;
                for (int i = 0; i < array.length(); i++) {
                    Object arrayElement = array.get(i);
                    if (arrayElement instanceof JSONObject) {
                        String result = findFirstDestinationValue((JSONObject) arrayElement);
                        if (result != null) {
                            return result;
                        }
                    }
                }
            }
        }

        return null;
    }

    private static String generateRandomString(int length) {
        String characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        Random random = new SecureRandom();
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            int index = random.nextInt(characters.length());
            sb.append(characters.charAt(index));
        }
        return sb.toString();
    }
}

